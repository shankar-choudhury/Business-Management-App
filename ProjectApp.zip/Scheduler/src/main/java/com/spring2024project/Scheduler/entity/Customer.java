package com.spring2024project.Scheduler.entity;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "customer")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column
    private String firstName;
    @Column
    private String lastName;
    @Column
    private long phoneNumber;
    @OneToMany
    private List<Address> addresses = List.of();
    @OneToMany
    private List<CreditCard> cards = List.of();
    @OneToMany
    private List<Generator> generators = List.of();

    public Customer(){};
    private Customer(String firstName, String lastName, long phoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
    }

    private Customer(int id, String firstName, String lastName, long phoneNumber) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
    }

    public int getId() {
        return id;
    }
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public static Customer defaultCustomer() {
        return new Customer("","",0);
    }

    public static Customer of(String firstName, String lastName, long phoneNumber) {
        return new Customer(firstName, lastName, phoneNumber);
    }

    public static Customer from(Customer c) {
        return new Customer(c.getId(), c.getFirstName(), c.getLastName(), c.getPhoneNumber());
    }
}
