package com.spring2024project.Scheduler.service;

import com.spring2024project.Scheduler.entity.Customer;
import com.spring2024project.Scheduler.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.spring2024project.Scheduler.entity.Customer.*;

import java.util.List;

@Service
public class CustomerServiceImp implements CustomerService{
    private CustomerRepository cr;

    @Autowired
    public CustomerServiceImp(CustomerRepository cr) {
        this.cr = cr;
    }

    @Override
    public List<Customer> getAllCustomers() {
        return (List<Customer>) cr.findAll();
    }

    @Override
    public Customer getCustomerByID(int id) {
        return cr.findById(id).orElse(defaultCustomer());
    }

    @Override
    public Customer createCustomer(String firstName, String lastName, long phoneNumber) {
        return cr.save(of(firstName, lastName, phoneNumber));
    }

    @Override
    public Customer updateCustomer(int id, String firstName, String lastName, long phoneNumber) {
        Customer toUpdate = getCustomerByID(id);
        if (!toUpdate.getFirstName().isEmpty()) {
            toUpdate.setFirstName(firstName);
            toUpdate.setLastName(lastName);
            toUpdate.setPhoneNumber(phoneNumber);
            cr.save(toUpdate);
        }
        return toUpdate;
    }

    @Override
    public Customer deleteCustomer(int id) {
        Customer toDelete = getCustomerByID(id);
        if (!toDelete.getFirstName().isEmpty()) {
            Customer save = Customer.from(toDelete);
            cr.deleteById(id);
            return save;
        }
        return toDelete;
    }
}
