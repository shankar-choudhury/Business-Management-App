package com.spring2024project.Scheduler.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "creditcard")
public class CreditCard {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column
    private long number;
    @Column
    private int expMonth;
    @Column
    private int expYear;
    @ManyToOne
    private Address billing;

    private CreditCard(){};

    private CreditCard(long number, int expMonth, int expYear, Address billing) {
        this.number = number;
        this.expMonth = expMonth;
        this.expYear = expYear;
        this.billing = billing;
    }

    private CreditCard(int id, long number, int expMonth, int expYear, Address billing) {
        this.id = id;
        this.number = number;
        this.expMonth = expMonth;
        this.expYear = expYear;
        this.billing = billing;
    }

    public int getId() {
        return id;
    }

    public long getNumber() {
        return number;
    }

    public void setNumber(long number) {
        this.number = number;
    }

    public int getExpMonth() {
        return expMonth;
    }

    public void setExpMonth(int expMonth) {
        this.expMonth = expMonth;
    }

    public int getExpYear() {
        return expYear;
    }

    public void setExpYear(int expYear) {
        this.expYear = expYear;
    }

    public Address getBilling() {return billing;}

    public void setBilling(Address billing) {this.billing = billing;}

    public static CreditCard of(long number, int expMonth, int expYear, Address billing) {
        return new CreditCard(number, expMonth, expYear, billing);
    }

    public static CreditCard defaultCC() {
        return new CreditCard(0,0, 0, 0, Address.defaultAddress());
    }

    public static CreditCard from(CreditCard c) {
        return new CreditCard(c.getId(), c.getNumber(),
                c.getExpMonth(), c.getExpYear(), c.getBilling());
    }

}
