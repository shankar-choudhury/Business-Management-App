package com.spring2024project.Scheduler.entity;

import jakarta.persistence.*;

@Entity
@Table(uniqueConstraints = {
        @UniqueConstraint(columnNames = {"buildingNumber", "street", "city", "state", "zipcode"})
})
public class Address {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column
    private int buildingNumber;
    @Column
    private String street;
    @Column
    private String city;
    @Column
    private String state;
    @Column
    private int zipcode;

    public Address(){};

    private Address(int buildingNumber, String street, String city, String state, int zipcode) {
        this.buildingNumber = buildingNumber;
        this.street = street;
        this.city = city;
        this.state = state;
        this.zipcode = zipcode;
    }

    private Address(int id, int buildingNumber, String street, String city, String state, int zipcode) {
        this.id = id;
        this.buildingNumber = buildingNumber;
        this.street = street;
        this.city = city;
        this.state = state;
        this.zipcode = zipcode;
    }


    public int getId() {
        return id;
    }

    public int getBuildingNumber() {
        return buildingNumber;
    }

    public void setBuildingNumber(int buildingNumber) {
        this.buildingNumber = buildingNumber;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public int getZipcode() {
        return zipcode;
    }

    public void setZipcode(int zipcode) {
        this.zipcode = zipcode;
    }

    public static Address defaultAddress() {
        return new Address(0,0, "", "", "", 0);
    }

    public static Address of(int buildingNumber, String street, String city, String state, int zipcode) {
        return new Address(buildingNumber, street, state, city, zipcode);
    }

    public static Address from(Address a) {
        return new Address(a.getId(), a.getBuildingNumber(), a.getStreet(),
                a.getCity(), a.getState(), a.getZipcode());
    }
}
