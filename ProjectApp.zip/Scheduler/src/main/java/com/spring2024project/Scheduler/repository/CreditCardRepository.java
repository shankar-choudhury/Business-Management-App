package com.spring2024project.Scheduler.repository;

import com.spring2024project.Scheduler.entity.CreditCard;
import org.springframework.data.repository.CrudRepository;

public interface CreditCardRepository extends CrudRepository<CreditCard,Integer> {
}
