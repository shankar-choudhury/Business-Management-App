package com.spring2024project.Scheduler.repository;

import com.spring2024project.Scheduler.entity.Generator;
import org.springframework.data.repository.CrudRepository;

public interface GeneratorRepository extends CrudRepository<Generator,Integer> {
}
