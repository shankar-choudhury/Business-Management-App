package com.spring2024project.Scheduler.repository;

import com.spring2024project.Scheduler.entity.Address;
import org.springframework.data.repository.CrudRepository;

public interface AddressRepository extends CrudRepository<Address, Integer> {
}
