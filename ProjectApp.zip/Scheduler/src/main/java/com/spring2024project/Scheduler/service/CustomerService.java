package com.spring2024project.Scheduler.service;

import com.spring2024project.Scheduler.entity.Customer;

import java.util.List;

public interface CustomerService {

    List<Customer> getAllCustomers();
    Customer getCustomerByID(int id);
    Customer createCustomer(String firstName, String lastName, long phoneNumber);
    Customer updateCustomer(int id, String firstName, String lastName, long phoneNumber);
    Customer deleteCustomer(int id);
}
