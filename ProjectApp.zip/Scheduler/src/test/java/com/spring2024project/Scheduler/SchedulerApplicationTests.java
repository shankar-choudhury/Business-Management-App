package com.spring2024project.Scheduler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}
